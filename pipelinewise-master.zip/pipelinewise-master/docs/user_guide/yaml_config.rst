
.. _yaml_configuration:

YAML configuration
------------------

.. warning::

  This section of the documentation is work in progress.

  Pipelines using YAML format for configurations. You can find some information
  and usage of these YAML files in the following sections:

  * :ref:`creating_pipelines`
  * :ref:`alerts`
  * :ref:`tap-jira`
  * :ref:`tap-kafka`
  * :ref:`tap-mongodb`
  * :ref:`tap-mysql`
  * :ref:`tap-postgres`
  * :ref:`tap-s3-csv`
  * :ref:`tap-snowflake`
  * :ref:`tap-zendesk`
  * :ref:`tap-github`
  * :ref:`tap-slack`
  * :ref:`tap-mixpanel`
  * :ref:`target-postgres`
  * :ref:`target-snowflake`
  * :ref:`target-s3-csv`
