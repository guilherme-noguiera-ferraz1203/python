1.1.2 (2021-03-16)
-------------------
- Fix missing elements for streams without ordered response

1.1.1 (2021-02-23)
-------------------
- Fix wrong JSON parsing of state.json

1.1.0 (2021-02-22)
-------------------
- Transforms stringified JSONs to JSON objects
- Enable streams to by synced since the last bookmark or start_date with query parameter
- Get more fields for events stream

1.0.2 (2021-01-21)
-------------------
- Fix publishing to PyPI

1.0.1 (2021-01-19)
-------------------
- Fix UsageRecords and UsageTriggers schemas
- Fix pagination for Account subresources

1.0.0 (2021-01-12)
-------------------

- Add programmable chat schemas and streams
- Add taskrouter streams

0.0.1 (2020-10-23)
-------------------

- Initial fork of singer-io/tap-twilio 0.0.1
