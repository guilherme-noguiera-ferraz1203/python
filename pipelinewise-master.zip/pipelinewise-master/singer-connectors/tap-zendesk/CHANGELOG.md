# Changelog

1.2.1 (2020-07-23)
------------------

- Use `start_time` query parameter for satisfaction_ratings stream

1.2.0 (2020-07-20)
------------------

- Make `rate_limit`, `max_workers` and `batch_size` options configurable

1.1.0 (2020-02-19)
------------------

- Make logging customizable

1.0.0 (2019-11-14)
------------------

- This is a fork of https://github.com/singer-io/tap-zendesk v1.4.6.
- Parallelize zendesk requests
